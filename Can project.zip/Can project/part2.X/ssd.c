

#include <xc.h>
#include "ssd.h"
void init_ssd()
{
    TRISD=0x00;
    
    TRISA=TRISA& 0xF0;
    PORTD=0X00;
    PORTA=PORTA&0xF0;
}
void display_ssd(unsigned char *ssd)
{
    for(int i=0;i<4;i++)
    {
        PORTD=ssd[i];
        PORTA=((PORTA & 0xF0)|(1<<i));
        for(unsigned int i=0;i<1000;i++);
    }
}


