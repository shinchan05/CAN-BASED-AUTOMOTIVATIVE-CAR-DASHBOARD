#include "xc.h"
#include "ecu2_Sensor.h"
#include "adc.h"
#include "can.h"
#include "digital_keypad.h"
//#includ e "msg_id.h"
//#include "uart.h"

volatile unsigned char led_state=0;


uint16_t get_rpm()
{
    //Implement the rpm function
     unsigned short  rpm=read_adc(CHANNEL4);
    return (rpm*5.865);
}

//uint16_t get_engine_temp()
//{
//    //Implement the engine temperature function
//}

IndicatorStatus process_indicator()
{
    //Implement the indicator function
    unsigned char key=read_digital_keypad(LEVEL);
    unsigned int delay=0;
        if(key==SWITCH1)
        {
//          if(delay++>= 50)
//        {
//            led_state = !led_state;
//            if(led_state)
//            {
//                RIGHT_IND_ON();
//            }
//            else
//            {
//                RIGHT_IND_OFF();
//            }
//
//            delay = 0;
//        }

        return e_ind_left;
        }
        else if(key==SWITCH2)
        {           
//              RIGHT_IND_OFF();               
//            LEFT_IND_OFF();
//            delay=0;
            return e_ind_off;
        }
        else if(key==SWITCH3)
        {
//            if(delay++ >= 50)
//        {
//            led_state = !led_state;
//
//            if(led_state)
//            {
//                LEFT_IND_ON();
//            }
//            else
//            {
//                LEFT_IND_OFF();
//            }
//
//            delay=0;
        //}

        return e_ind_right;
        }
        
}