#include<xc.h>
#include "ecu2_Sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "ssd.h"
#include "digital_keypad.h"
#include "ecu2_Sensor.h"
#include "clcd.h"

int main()
{
   // init_clcd();
    //call the functions
   init_digital_keypad();
    TRISB0=0;
    TRISB1=0;
    TRISB6=0;
    TRISB7=0;
    RB0=0;
    RB1=0;
    RB6=0;
    RB7=0;
     //PORTB=0;
    init_ssd();
    init_adc();
    init_can();
    unsigned char digit[]={ZERO,ONE,TWO,THREE,FOUR,FIVE,SIX,SEVEN,EIGHT,NINE};
    unsigned char ssd[4];
    uint16_t num;
    uint16_t imsg_id;
     uint8_t data[8];
     uint16_t smsg_id;
     uint16_t sdata[2];
     uint8_t idata[2];
   uint8_t slen;
   uint8_t leds[2];
     uint8_t ilen;

    while(1)
    {
        num=get_rpm();
        ssd[0]=(digit[num/1000])+48;
        ssd[1]=(digit[(num/100)%10])+48;
        ssd[2]=(digit[(num/10)%10])+48;
        ssd[3]=(digit[num%10])+48;
        
        display_ssd(ssd);
        ssd[0]=(num/1000)+48;
        ssd[1]=((num/100)%10)+48;
        ssd[2]=((num/10)%10)+48;
        ssd[3]=(num%10)+48;
        
        can_transmit(RPM_MSG_ID,ssd,4);
        __delay_ms(80);
      // can_receive(&smsg_id,data,&slen);
       
//       ssd[0]=digit[0]-48;
//       ssd[1]=digit[1]-48;
//       ssd[2]=digit[2]-48;
//       ssd[3]=digit[3]-48;
 //      data[4]='\0';
           
     //  display_ssd(ssd);//
        
       
       
       
        uint8_t led=process_indicator(); 
        leds[0]=led;
        //leds[1]='\0';
        
       can_transmit(INDICATOR_MSG_ID,leds,1);
       //__delay_ms(80);
      //  can_receive(&imsg_id,idata,&ilen);
//////  unsigned 
        unsigned int delay=0;
        
        
        if(idata[0]==e_ind_right)
        {
            if(delay++<=200)
                RIGHT_IND_ON();
            else if(delay++>=400)
            {
                delay=0;
            RIGHT_IND_OFF();
            }
            
            LEFT_IND_OFF();
            
        }
        else if(idata[0]==e_ind_left)
        {
            if(delay++<=200)
            LEFT_IND_ON();
            else if(delay++>=400)
            {
                delay=0;
             LEFT_IND_OFF();
            }
            RIGHT_IND_OFF();
        }
        else if(idata[0]==e_ind_off)
        {
          LEFT_IND_OFF();
          RIGHT_IND_OFF();
        }      
    }
}
