#include <xc.h>
#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
#include "uart.h"
#include  "clcd.h"
#include "matrix_keypad.h"


int main()
{
    //Call the functions
  
    init_clcd();
    init_adc();
    init_matrix_keypad();
    init_can();
    char *str="GEAR";
    char *spe="SPEED";
    unsigned char spp[3];
    uint16_t speed;
    uint16_t msg_id;
     uint16_t data[3];
     uint16_t gmsg_id;
     uint16_t gdata[3];
     unsigned int len;
     unsigned int len1;
     unsigned char pos[2];
    while(1)
    {
//       clcd_print(str, LINE1(0));
//       clcd_print(spe,LINE1(6));
       pos[0]=get_gear_pos();
       pos[1]='\0';
       can_transmit(GEAR_MSG_ID,pos,1);
       __delay_ms(80);
//       can_receive(&gmsg_id,gdata,&len1);
//       gdata[len1]='\0';
       
      // clcd_print(gdata,LINE2(0));
       
       
//       can_transmit(SPEED_MSG_ID,speed,2);
//       can_receive(&msg_id,data,&len);
       
        speed=get_speed();
        spp[0] = (speed/10)+'0';
        spp[1] = (speed%10)+'0';
        spp[2] = '\0';
       
      can_transmit(SPEED_MSG_ID,spp,3);
      __delay_ms(80);
//       can_receive(&msg_id,data,&len);
//       
//       clcd_print(data,LINE2(6));
    }
}