#include<xc.h>
#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
#include "digital_keypad.h"
#include "matrix_keypad.h"



uint16_t get_speed()
{
    // Implement the speed function
    unsigned short speed=read_adc(CHANNEL4);
    
    return (speed/10);
    
}

unsigned char get_gear_pos()
{
    // Implement the gear function
   unsigned  char str[8]={'N','1','2','3','4','5','R','C'};
   static unsigned int gear=0;
   
   unsigned char key=read_switches(STATE_CHANGE);
   if(key==MK_SW3)
   {
       gear=7;       
   }
   if((gear==7)&&((key==MK_SW1)||(key==MK_SW2)))
   {
       gear=0;
   }
   else if((key==MK_SW1)&&(gear<6))
   {
       gear++;
   }
   else if((key==MK_SW2)&&(gear>0))
   {
       gear--;
   }
   
   return str[gear];
}
