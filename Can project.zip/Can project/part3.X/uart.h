///* 
// * File:   uart.h
// * Author: reddy
// *
// * Created on 28 May, 2026, 10:26 PM
// */
//
//#ifndef UART_H
//#define	UART_H
//
//#ifdef	__cplusplus
//extern "C" {
//#endif
//
//
//
//
//#ifdef	__cplusplus
//}
//#endif
//
//#endif	/* UART_H */
//
