#include<xc.h>
#include"message_handler.h"

volatile unsigned char led_state = 0;

void __interrupt()isr()
{
    static unsigned int count=0;
    if(TMR0IF==1)
    {
        TMR0=TMR0+8;//why we are asdding +8
       if(count++==1000) 
       {
          count=0; 
                  led_state^=1;
       }
       TMR0IF=0;
    }
}

