#include <xc.h>
#include <stdint.h>
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
//#include "message_handler.h"
#include "timer0.h"


 void process_canbus_data();
void init_leds() {
    TRISB = 0x08; 
    PORTB = 0x00;
}

static void init_config(void) {
    // Initialize CLCD and CANBUS
    init_clcd();
    init_can();
    init_leds();

    // Enable Interrupts
    PEIE = 1;
    GIE = 1;
    init_timer0();
}

void main(void) {
    // Initialize peripherals
    init_config();
    init_clcd();
    /* ECU1 main loop */
    while (1) {
        // Read CAN Bus data and handle it
        
        process_canbus_data();
    }

    return;
}
