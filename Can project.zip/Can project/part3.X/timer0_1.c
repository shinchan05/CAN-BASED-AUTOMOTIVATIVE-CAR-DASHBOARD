#include <xc.h>
#include "timer0.h"

void init_timer0(void) {
   TMR0ON=1;
    T08BIT=1;
    T0CS=0;
    //T0SE=1;
    PSA=1;
    GIE=1;
    PEIE=1;
    TMR0IE=1;
    TMR0IF=0;
    TMR0=6;
}
